<!-- src/App.vue -->
<template>
  <router-view />
</template>

<script setup>
</script>

<style>
/* giữ layout global nếu cần */
body { background: #f6f7f9; }
</style>
