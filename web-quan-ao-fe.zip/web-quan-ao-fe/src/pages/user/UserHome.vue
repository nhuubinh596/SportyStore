<!-- src/pages/user/UserHome.vue -->
<template>
  <div>
    <!-- Small filter row -->
    <div class="mb-3 d-flex align-items-center gap-3">
      <label>Danh mục:</label>
      <select v-model="category" class="form-select w-auto">
        <option value="">Tất cả</option>
        <option v-for="c in categories" :key="c" :value="c">{{ c }}</option>
      </select>

      <label class="ms-3">Giá tối đa:</label>
      <input type="number" v-model.number="maxPrice" class="form-control w-auto" />
    </div>

    <!-- Products grid -->
    <div class="row g-3">
      <div v-for="p in filteredProducts" :key="p.id" class="col-12 col-sm-6 col-md-4 col-lg-3">
        <div class="card h-100 shadow-sm">
          <img :src="p.image" class="card-img-top" style="height:180px;object-fit:cover" />
          <div class="card-body d-flex flex-column">
            <h6 class="card-title" style="min-height:44px">{{ p.title }}</h6>
            <div class="mb-2 text-primary fw-bold">{{ formatPrice(p.price) }}</div>
            <div class="mt-auto d-flex gap-2">
              <button class="btn btn-sm btn-outline-secondary" @click="view(p)">Xem</button>
              <button class="btn btn-sm btn-dark" @click="addToCart(p)">Thêm vào giỏ</button>
            </div>
          </div>
        </div>
      </div>

      <div v-if="filteredProducts.length === 0" class="col-12">
        <div class="alert alert-info">Không tìm thấy sản phẩm phù hợp.</div>
      </div>
    </div>

  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

// demo products (replace with API call when backend ready)
const products = ref([
  { id: 1, title: 'Áo Thun DryFit Xanh', price: 299000, image: '/src/assets/logo.svg', category: 'Áo' },
  { id: 2, title: 'Quần Short Nam Đen', price: 199000, image: '/src/assets/logo.svg', category: 'Quần' },
  { id: 3, title: 'Giày Lightning', price: 1290000, image: '/src/assets/logo.svg', category: 'Giày' },
  { id: 4, title: 'Mũ Lưỡi Trai', price: 150000, image: '/src/assets/logo.svg', category: 'Phụ kiện' }
])

const categories = ref(['Áo', 'Quần', 'Giày', 'Phụ kiện'])
const category = ref('')
const maxPrice = ref(0)

const filteredProducts = computed(() => {
  return products.value.filter(p => {
    if (category.value && p.category !== category.value) return false
    if (maxPrice.value && p.price > (maxPrice.value || 0)) return false
    return true
  })
})

function addToCart(p) {
  const cartRaw = localStorage.getItem('cart')
  const cart = cartRaw ? JSON.parse(cartRaw) : []
  cart.push({ ...p, qty: 1 })
  localStorage.setItem('cart', JSON.stringify(cart))
  // update header (we used localStorage reading) — quick feedback:
  alert('Đã thêm vào giỏ.')
}

function view(p) {
  // placeholder: route to product detail page if exists
  alert('Xem sản phẩm: ' + p.title)
}

function formatPrice(v) {
  return v.toLocaleString('vi-VN') + ' ₫'
}

// If user searched in header, read that
onMounted(() => {
  const s = localStorage.getItem('userSearch') || ''
  if (s) {
    // simple filter by title
    const term = s.toLowerCase()
    products.value = products.value.filter(p => p.title.toLowerCase().includes(term))
    localStorage.removeItem('userSearch')
  }
})
</script>

<style scoped>
.card { border-radius:10px; }
</style>
