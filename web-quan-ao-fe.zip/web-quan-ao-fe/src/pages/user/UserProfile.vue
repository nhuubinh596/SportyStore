<template>
  <div class="profile box">
    <h3>Thông tin cá nhân</h3>
    <form @submit.prevent="save">
      <div class="row">
        <label>Tài khoản (username)</label>
        <input v-model="form.username" readonly />
      </div>
      <div class="row">
        <label>Họ tên</label>
        <input v-model="form.name" />
      </div>
      <div class="row">
        <label>Email</label>
        <input v-model="form.email" />
      </div>
      <div class="row">
        <label>Số điện thoại</label>
        <input v-model="form.phone" />
      </div>

      <div class="actions">
        <button type="submit">Lưu</button>
      </div>
    </form>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
const form = ref({ username:'', name:'', email:'', phone:'' })

onMounted(()=>{
  try {
    const u = JSON.parse(localStorage.getItem('currentUser'))
    if(u) form.value = { username: u.username||'', name: u.name||'', email: u.email||'', phone: u.phone||'' }
  } catch(e){ }
})

function save(){
  // lưu vào currentUser
  try {
    const cur = JSON.parse(localStorage.getItem('currentUser') || '{}')
    const updated = { ...cur, ...form.value }
    localStorage.setItem('currentUser', JSON.stringify(updated))
    alert('Đã lưu thông tin')
  } catch(e){ alert('Lỗi lưu') }
}
</script>

<style scoped>
.profile{ max-width:760px; }
.row{ margin-bottom:10px; display:flex; flex-direction:column; gap:6px; }
.row input{ padding:8px; border-radius:6px; border:1px solid #ddd; }
.actions button{ padding:8px 12px; border-radius:6px; background:#111; color:#fff; border:0; }
</style>
