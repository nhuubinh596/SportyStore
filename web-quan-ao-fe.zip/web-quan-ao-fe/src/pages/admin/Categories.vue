<template>
  <div>
    <h3>Danh mục</h3>

    <div class="form-inline">
      <input v-model="name" placeholder="Tên danh mục" />
      <button @click="add" class="btn">Thêm</button>
      <button v-if="editing" @click="cancelEdit" class="btn muted">Hủy</button>
    </div>

    <ul class="list">
      <li v-for="c in categories" :key="c.id">
        <div class="left">{{ c.name }}</div>
        <div class="right">
          <button @click="edit(c)">Sửa</button>
          <button @click="remove(c.id)" class="btn-del">Xóa</button>
        </div>
      </li>
    </ul>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import API from '@/api';

const categories = ref([]);
const name = ref('');
const editing = ref(false);
const editId = ref(null);

async function load() {
  try {
    const res = await API.get('/admin/categories');
    categories.value = res.data;
  } catch (e) { console.error(e); }
}

async function add() {
  if (!name.value.trim()) return;
  try {
    if (editing.value) {
      await API.put(`/admin/categories/${editId.value}`, { name: name.value });
      editing.value = false; editId.value = null;
    } else {
      await API.post('/admin/categories', { name: name.value });
    }
    name.value = '';
    await load();
  } catch (e) { console.error(e); }
}

function edit(c) {
  editing.value = true;
  editId.value = c.id;
  name.value = c.name;
}

function cancelEdit() {
  editing.value = false; editId.value = null; name.value = '';
}

async function remove(id) {
  if (!confirm('Xóa danh mục?')) return;
  try {
    await API.delete('/admin/categories/' + id);
    categories.value = categories.value.filter(x=>x.id !== id);
  } catch (e) { console.error(e); }
}

onMounted(load);
</script>

<style scoped>
.form-inline { display:flex; gap:8px; margin-bottom:12px; }
.input { padding:6px 8px; }
.list { list-style:none; padding:0; margin:0; }
.list li { background:#fff; padding:8px 12px; margin-bottom:8px; display:flex; justify-content:space-between; align-items:center; border-radius:8px; }
.btn { padding:6px 10px; }
.btn-del { padding:6px 10px; border:1px solid #e74c3c; color:#e74c3c; background:#fff; border-radius:6px; }
</style>
