<template>
  <div>
    <div class="top">
      <h3>Sản phẩm</h3>
      <div>
        <select v-model="filterCategory">
          <option value="">Tất cả danh mục</option>
          <option v-for="c in categories" :key="c.id" :value="c.id">{{ c.name }}</option>
        </select>
        <button @click="openNew" class="btn">Thêm sản phẩm</button>
      </div>
    </div>

    <div class="grid">
      <div class="card" v-for="p in displayed" :key="p.id">
        <div class="img" :style="{ backgroundImage: 'url(' + (p.imageUrl || placeholder) + ')' }"></div>
        <div class="title">{{ p.namtre }}</div>
        <div class="price">{{ formatCurrency(p.price) }}</div>
        <div class="actions">
          <button @click="openEdit(p)">Sửa</button>
          <button @click="remove(p.id)" class="btn-del">Xóa</button>
        </div>
      </div>
    </div>

    <!-- modal -->
    <div v-if="show" class="modal">
      <div class="modal-body">
        <h4>{{ editId ? 'Sửa' : 'Thêm' }} sản phẩm</h4>
        <div class="row"><label>Tên</label><input v-model="form.name" /></div>
        <div class="row"><label>Giá</label><input v-model.number="form.price" type="number" /></div>
        <div class="row"><label>Ảnh (URL)</label><input v-model="form.imageUrl" /></div>
        <div class="row"><label>Danh mục</label>
          <select v-model="form.categoryId">
            <option v-for="c in categories" :value="c.id" :key="c.id">{{ c.name }}</option>
          </select>
        </div>
        <div class="row actions">
          <button @click="save">Lưu</button>
          <button @click="close">Hủy</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import API from '@/api';

const categories = ref([]);
const products = ref([]);
const filterCategory = ref('');
const placeholder = '/logo.svg'; // dùng logo nếu chưa có ảnh

// modal + form
const show = ref(false);
const editId = ref(null);
const form = ref({ name:'', price:0, imageUrl:'', categoryId: null });

function formatCurrency(v){ return v == null ? '-' : v.toLocaleString() + ' đ'; }

async function loadAll() {
  try {
    const [cRes, pRes] = await Promise.all([API.get('/admin/categories'), API.get('/admin/products')]);
    categories.value = cRes.data;
    products.value = pRes.data;
  } catch (e) { console.error(e); }
}

const displayed = computed(() => {
  if (!filterCategory.value) return products.value;
  return products.value.filter(p => p.category && String(p.category.id) === String(filterCategory.value));
});

function openNew() {
  editId.value = null;
  form.value = { name:'', price:0, imageUrl:'', categoryId: categories.value.length ? categories.value[0].id : null };
  show.value = true;
}

function openEdit(p) {
  editId.value = p.id;
  form.value = {
    name: p.name,
    price: p.price,
    imageUrl: p.imageUrl || '',
    categoryId: p.category ? p.category.id : null
  };
  show.value = true;
}

async function save() {
  try {
    const payload = {
      name: form.value.name,
      price: form.value.price,
      imageUrl: form.value.imageUrl,
      category: { id: form.value.categoryId }
    };
    if (editId.value) {
      await API.put('/admin/products/' + editId.value, payload);
    } else {
      await API.post('/admin/products', payload);
    }
    show.value = false;
    await loadAll();
  } catch (e) { console.error(e); alert('Lưu lỗi'); }
}

function close() { show.value = false; }

async function remove(id) {
  if (!confirm('Xóa sản phẩm?')) return;
  try {
    await API.delete('/admin/products/' + id);
    products.value = products.value.filter(x => x.id !== id);
  } catch (e) { console.error(e); alert('Xóa lỗi'); }
}

onMounted(loadAll);
</script>

<style scoped>
.top { display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; }
.grid { display:grid; grid-template-columns:repeat(4, 1fr); gap:18px; }
.card { background:#fff; padding:12px; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,0.03); display:flex; flex-direction:column; gap:8px; }
.img { height:140px; background-size:cover; background-position:center; border-radius:6px; }
.actions { display:flex; gap:8px; margin-top:auto; }
.btn-del { border:1px solid #e74c3c; color:#e74c3c; padding:6px 8px; border-radius:6px; }
.modal { position:fixed; inset:0; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.35); }
.modal-body { background:#fff; padding:18px; border-radius:10px; width:520px; }
.row { margin-bottom:10px; display:flex; gap:8px; align-items:center; }
.row label { width:110px; }
.row input, row select { flex:1; padding:6px 8px; border-radius:6px; border:1px solid #ddd; }
</style>
