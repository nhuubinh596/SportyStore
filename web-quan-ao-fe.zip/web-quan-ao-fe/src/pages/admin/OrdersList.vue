<template>
  <div>
    <h3>Danh sách đơn hàng</h3>
    <table class="table">
      <thead><tr><th>ID</th><th>Khách</th><th>Ngày</th><th>Tổng</th><th>Số SP</th></tr></thead>
      <tbody>
        <tr v-for="o in orders" :key="o.id">
          <td>{{ o.id }}</td>
          <td>{{ o.username }}</td>
          <td>{{ formatDate(o.createdAt) }}</td>
          <td>{{ formatCurrency(o.totalAmount) }}</td>
          <td>{{ (o.items || []).length }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import API from '@/api';

const orders = ref([]);

async function load() {
  try {
    const res = await API.get('/admin/orders');
    orders.value = res.data;
  } catch (e) { console.error(e); }
}

function formatDate(d){ return d ? new Date(d).toLocaleString() : '-'; }
function formatCurrency(v){ return v == null ? '-' : v.toLocaleString() + ' đ'; }

onMounted(load);
</script>

<style scoped>
.table { width:100%; background:#fff; border-radius:8px; overflow:hidden; }
.table th, .table td { padding:10px 12px; border-bottom:1px solid #eee; }
</style>
