<template>
  <div>
    <div class="top">
      <h3>Danh sách người dùng</h3>
      <input v-model="q" placeholder="Tìm username hoặc email" />
    </div>

    <table class="table">
      <thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Hành động</th></tr></thead>
      <tbody>
        <tr v-for="u in filtered" :key="u.id">
          <td>{{ u.id }}</td>
          <td>{{ u.username }}</td>
          <td>{{ u.email }}</td>
          <td>{{ u.role || (u.roles ? u.roles.join(',') : '-') }}</td>
          <td>
            <button @click="deleteUser(u.id)" class="btn-del">Xóa</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import API from '@/api';

const users = ref([]);
const q = ref('');

async function load() {
  try {
    const res = await API.get('/admin/users');
    users.value = res.data;
  } catch (e) {
    console.error(e);
  }
}

async function deleteUser(id) {
  if (!confirm('Xác nhận xóa user ' + id + '?')) return;
  try {
    await API.delete('/admin/users/' + id);
    users.value = users.value.filter(x => x.id !== id);
  } catch (e) {
    console.error(e);
    alert('Xóa thất bại');
  }
}

const filtered = computed(() => {
  const qv = q.value.trim().toLowerCase();
  if (!qv) return users.value;
  return users.value.filter(u => (u.username||'').toLowerCase().includes(qv) || (u.email||'').toLowerCase().includes(qv));
});

onMounted(load);
</script>

<style scoped>
.top { display:flex; gap:12px; align-items:center; margin-bottom:12px; }
.table { width:100%; background:#fff; border-radius:8px; overflow:hidden; }
.table th, .table td { padding:10px 12px; border-bottom:1px solid #eee; }
.btn-del { padding:6px 10px; border:1px solid #e74c3c; color:#e74c3c; background:#fff; border-radius:6px; cursor:pointer; }
</style>
