<template>
  <div class="p-4">
    <h2>Thông tin tài khoản</h2>
    <div class="card p-3 mt-3" style="max-width:700px;">
      <div class="d-flex gap-3 align-items-center">
        <img :src="avatarUrl" class="avatar" />
        <div>
          <div class="h5">{{ user?.name || user?.username }}</div>
          <div class="text-muted">@{{ user?.username }}</div>
          <div class="mt-2"><strong>Role:</strong> {{ roleLabel }}</div>
        </div>
      </div>

      <hr />

      <div><strong>Email:</strong> {{ user?.email || '-' }}</div>
      <div class="mt-2"><strong>Số điện thoại:</strong> {{ user?.phone || '-' }}</div>
      <div class="mt-3">
        <button class="btn btn-outline-secondary" @click="onLogout">Đăng xuất</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const user = ref(null)
const router = useRouter()

onMounted(()=> {
  try { user.value = JSON.parse(localStorage.getItem('currentUser')) } catch(e){ user.value = null }
})

const roleLabel = computed(()=> {
  if (!user.value) return 'GUEST'
  return (user.value.role || (user.value.roles && user.value.roles[0]) || 'USER').replace(/^ROLE_/,'')
})
const avatarUrl = computed(()=> user.value?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.value?.name || user.value?.username || 'U')}`)

function onLogout(){
  localStorage.removeItem('currentUser')
  localStorage.removeItem('authToken')
  router.replace('/login')
}
</script>

<style scoped>
.avatar{ width:80px; height:80px; border-radius:12px; object-fit:cover; border:1px solid #eee; }
.card{ border-radius:10px; }
</style>
