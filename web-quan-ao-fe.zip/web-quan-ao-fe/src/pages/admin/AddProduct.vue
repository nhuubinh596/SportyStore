<template>
  <div>
    <h2>Thêm sản phẩm</h2>
    <div style="margin-top:12px;max-width:520px">
      <label>Tên</label>
      <input style="width:100%;padding:10px;border-radius:8px;border:1px solid #e6e9ef;margin-top:6px" />
      <label style="margin-top:10px">Giá</label>
      <input style="width:100%;padding:10px;border-radius:8px;border:1px solid #e6e9ef;margin-top:6px" />
      <div style="margin-top:14px">
        <button class="btn">Lưu (demo)</button>
      </div>
    </div>
  </div>
</template>

<script setup></script>

<style scoped>
.form{ margin-top:12px; display:flex; flex-direction:column; gap:10px; max-width:520px; }
input{ padding:10px; border-radius:8px; border:1px solid #e6e9ef; }
.btn{ padding:10px 14px; border-radius:10px; background: #111; color:#fff; border:none; cursor:pointer; }
</style>
