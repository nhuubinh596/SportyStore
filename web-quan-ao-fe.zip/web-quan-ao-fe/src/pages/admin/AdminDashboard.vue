<template>
  <div>
    <h2>Dashboard</h2>
    <div class="cards">
      <div class="card">
        <div class="num">{{ stats.products }}</div>
        <div class="label">Sản phẩm</div>
      </div>
      <div class="card">
        <div class="num">{{ stats.categories }}</div>
        <div class="label">Danh mục</div>
      </div>
      <div class="card">
        <div class="num">{{ stats.orders }}</div>
        <div class="label">Đơn hàng</div>
      </div>
      <div class="card">
        <div class="num">{{ stats.users }}</div>
        <div class="label">Tài khoản</div>
      </div>
    </div>

    <h3 class="mt">Đơn hàng mới</h3>
    <table class="table">
      <thead><tr><th>ID</th><th>Username</th><th>Ngày</th><th>Tổng</th></tr></thead>
      <tbody>
        <tr v-for="o in recent" :key="o.id">
          <td>{{ o.id }}</td>
          <td>{{ o.username }}</td>
          <td>{{ formatDate(o.createdAt) }}</td>
          <td>{{ formatCurrency(o.totalAmount) }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import API from '@/api';

const stats = ref({ products: 0, categories: 0, orders: 0, users: 0 });
const recent = ref([]);

function formatDate(d) {
  if (!d) return '-';
  return new Date(d).toLocaleString();
}
function formatCurrency(v){ return v == null ? '-' : v.toLocaleString() + ' đ'; }

async function loadStats() {
  try {
    const [p, c, o, u] = await Promise.all([
      API.get('/admin/products'),
      API.get('/admin/categories'),
      API.get('/admin/orders'),
      API.get('/admin/users')
    ]);
    stats.value.products = p.data.length;
    stats.value.categories = c.data.length;
    stats.value.orders = o.data.length;
    stats.value.users = u.data.length;
    recent.value = o.data.slice().sort((a,b)=> new Date(b.createdAt)-new Date(a.createdAt)).slice(0,5);
  } catch (e) {
    console.error(e);
  }
}

onMounted(loadStats);
</script>

<style scoped>
.cards { display:flex; gap:16px; margin-bottom:20px; }
.card { background:#fff; padding:20px; border-radius:8px; width:160px; text-align:center; box-shadow:0 2px 6px rgba(0,0,0,0.03); }
.num { font-size:22px; font-weight:700; color:#111; }
.label { color:#666; }
.table { width:100%; border-collapse:collapse; background:#fff; border-radius:8px; overflow:hidden; }
.table th, .table td { padding:10px 12px; border-bottom:1px solid #eee; text-align:left; }
.mt { margin-top:20px; }
</style>
