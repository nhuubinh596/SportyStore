// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router';

// Auth
import Login from '../components/Auth/Login.vue';
import Register from '../components/Auth/Register.vue';

// Admin pages
import AdminLayout from '../components/admin/AdminLayout.vue';
import AdminDashboard from '../pages/admin/AdminDashboard.vue';
import ProductsList from '../pages/admin/ProductsList.vue';
import Categories from '../pages/admin/Categories.vue';
import OrdersList from '../pages/admin/OrdersList.vue';
import UsersList from '../pages/admin/UsersList.vue';

// User pages
import UserLayout from '../components/user/UserLayout.vue';
import UserHome from '../pages/user/UserHome.vue';
import UserOrders from '../pages/user/UserOrders.vue';
import UserProfile from '../pages/user/UserProfile.vue';

// fallback component (optional)
const NotFound = { template: '<div style="padding:40px">Not found</div>' };

const routes = [
  { path: '/', redirect: '/login' },

  { path: '/login', component: Login },
  { path: '/register', component: Register },

  {
    path: '/admin',
    component: AdminLayout,
    children: [
      { path: '', component: AdminDashboard },
      { path: 'products', component: ProductsList },
      { path: 'categories', component: Categories },
      { path: 'orders', component: OrdersList },
      { path: 'users', component: UsersList }
    ]
  },

  {
    path: '/user',
    component: UserLayout,
    children: [
      { path: '', component: UserHome },
      { path: 'orders', component: UserOrders },
      { path: 'profile', component: UserProfile }
    ]
  },

  { path: '/:catchAll(.*)', component: NotFound }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

function readCurrentUser() {
  try {
    const raw = localStorage.getItem('currentUser');
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    // normalize: ensure role / roles exists
    if (!parsed.role) {
      if (parsed.roles && parsed.roles.length) {
        parsed.role = parsed.roles[0];
      } else if (parsed.username) {
        const uname = String(parsed.username).toLowerCase();
        parsed.role = uname.includes('admin') ? 'ROLE_ADMIN' : 'ROLE_USER';
      } else {
        parsed.role = 'ROLE_USER';
      }
    }
    // ensure roles array
    if (!parsed.roles) parsed.roles = [parsed.role];
    return parsed;
  } catch (e) {
    console.error('Failed parse currentUser', e);
    return null;
  }
}

router.beforeEach((to, from, next) => {
  const user = readCurrentUser();
  const isLoggedIn = !!user;

  // allow login/register always
  if (!isLoggedIn && to.path !== '/login' && to.path !== '/register') {
    return next('/login');
  }

  if (isLoggedIn) {
    const roleStr = String(user.role || '').toLowerCase();
    // if admin trying to go to login -> redirect to /admin
    if (roleStr.includes('admin') && to.path === '/login') return next('/admin');
    // if user (not admin) trying to access /admin -> redirect to /user
    if (!roleStr.includes('admin') && to.path.startsWith('/admin')) return next('/user');
    // if admin trying to access /user root, allow admin -> maybe you want admin to manage users only
    // But to keep expected behavior: if admin hits /user redirect to /admin
    if (roleStr.includes('admin') && to.path.startsWith('/user')) return next('/admin');
  }

  return next();
});

export default router;
