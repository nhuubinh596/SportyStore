<template>
  <footer class="user-footer">
    <div class="wrap">
      <div>© SportyClothes - Demo</div>
      <div>Liên hệ | Trợ giúp | Điều khoản</div>
    </div>
  </footer>
</template>

<script setup></script>

<style scoped>
.user-footer{ border-top:1px solid #eee; background:#fff; padding:14px 0; margin-top:20px; }
.wrap{ max-width:1200px; margin:0 auto; display:flex; justify-content:space-between; align-items:center; padding:0 16px; color:#666; font-size:14px; }
</style>
