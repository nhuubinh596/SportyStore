<template>
  <header class="app-header">
    <div class="container-left">
      <div class="brand" @click="goHome">SportyClothes</div>
      <div class="search">
        <input v-model="q" @keydown.enter="onSearch" placeholder="Tìm sản phẩm..." />
        <button @click="onSearch">Tìm</button>
      </div>
    </div>

    <div class="container-right">
      <div class="hello">Xin chào, <strong>{{ username }}</strong></div>

      <!-- dropdown simple -->
      <div class="dropdown" @click="toggle">
        <span class="avatar">▾</span>
        <div v-if="open" class="menu">
          <a @click="goProfile">Thông tin tài khoản</a>
          <a @click="goOrders">Đơn hàng</a>
          <hr/>
          <a class="danger" @click="logout">Đăng xuất</a>
        </div>
      </div>
    </div>
  </header>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const open = ref(false)
const q = ref('')

function toggle() { open.value = !open.value }
function onSearch() {
  // placeholder: chuyển sang trang search nếu cần
  if (q.value && q.value.trim()) {
    router.push({ path: '/user', query: { q: q.value } })
  }
}

const current = JSON.parse(localStorage.getItem('currentUser') || 'null') || {}
const username = computed(() => current.username || current.name || 'Khách')

// actions
function logout() {
  localStorage.removeItem('currentUser')
  localStorage.removeItem('authToken')
  router.replace('/login')
}
function goProfile(){ router.push('/user/profile') }
function goOrders(){ router.push('/user/orders') }
function goHome(){ router.push('/user') }
</script>

<style scoped>
.app-header{
  display:flex;
  justify-content:space-between;
  align-items:center;
  padding:12px 20px;
  border-bottom:1px solid #eee;
  background:white;
}
.container-left{display:flex;align-items:center;gap:16px}
.brand{font-weight:700;cursor:pointer}
.search input{width:420px;padding:8px 10px;border-radius:6px;border:1px solid #ddd}
.search button{margin-left:8px;padding:8px 12px;border-radius:6px}
.container-right{display:flex;align-items:center;gap:12px}
.dropdown{position:relative;cursor:pointer}
.menu{
  position:absolute;right:0;top:30px;background:white;border:1px solid #eee;
  box-shadow:0 6px 18px rgba(0,0,0,0.06);border-radius:6px;padding:8px;width:180px;
  display:flex;flex-direction:column;gap:6px
}
.menu a{cursor:pointer;padding:6px 8px;border-radius:4px}
.menu a:hover{background:#f5f5f5}
.menu .danger{color:#b00}
.hello{font-size:14px;color:#333}
</style>
