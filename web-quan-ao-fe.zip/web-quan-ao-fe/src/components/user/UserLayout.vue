<!-- src/components/user/UserLayout.vue -->
<template>
  <div>
    <header class="app-header d-flex align-items-center justify-content-between p-2 border-bottom bg-white">
      <div class="ms-2"><strong>SportyClothes</strong></div>
      <div class="d-flex align-items-center">
        <input class="form-control me-2" placeholder="Tìm sản phẩm..." style="width:420px"/>
        <div class="dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
            Xin chào, <strong>{{ currentUser?.username }}</strong>
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" @click="go('/user/profile')">Thông tin</a></li>
            <li><a class="dropdown-item" @click="go('/user/orders')">Đơn hàng</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item text-danger" @click="onLogout">Đăng xuất</a></li>
          </ul>
        </div>
      </div>
    </header>

    <div class="d-flex">
      <aside class="p-3 bg-white" style="width:220px; min-height: calc(100vh - 56px)">
        <div class="card mb-3 p-2"><div><strong>SportyClothes</strong><div>Xin chào, <b>{{ currentUser?.username }}</b></div></div></div>
        <div class="card p-2">
          <ul>
            <li><a @click="go('/user')">Trang cá nhân</a></li>
            <li><a @click="go('/user/orders')">Đơn hàng</a></li>
            <li><a @click="go('/user/profile')">Thông tin</a></li>
          </ul>
        </div>
      </aside>

      <main class="flex-fill p-4">
        <router-view />
      </main>
    </div>

    <footer class="text-center py-2 border-top bg-white">© SportyClothes - Demo</footer>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
const router = useRouter();

const currentUser = ref(null);
try {
  currentUser.value = JSON.parse(localStorage.getItem('currentUser') || 'null');
} catch { currentUser.value = null; }

function onLogout() {
  localStorage.removeItem('currentUser');
  localStorage.removeItem('authToken');
  router.replace('/login');
}
function go(path) { router.push(path); }
</script>

<style scoped>
a { cursor: pointer; }
</style>
