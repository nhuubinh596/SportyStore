<template>
  <header class="admin-header">
    <div class="left">
      <button class="menu-toggle" @click="$emit('toggle')">☰</button>
      <div class="brand">SportyClothes</div>
    </div>

    <div class="right">
      <div class="greet">Xin chào, <strong>{{ user?.username || 'Khách' }}</strong></div>
      <button class="btn-logout" @click="logout">Logout</button>
    </div>
  </header>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
const user = ref(null)
const router = useRouter()

onMounted(()=> {
  try { user.value = JSON.parse(localStorage.getItem('currentUser')) } catch(e){ user.value = null }
})

function logout(){
  localStorage.removeItem('currentUser')
  localStorage.removeItem('authToken')
  router.replace('/login')
}
</script>

<style scoped>
.admin-header{ height:56px; display:flex; align-items:center; justify-content:space-between; padding:0 18px; border-bottom:1px solid #eee; background:#fff; }
.brand{ font-weight:700; margin-left:12px; }
.greet{ margin-right:12px; color:#333;}
.btn-logout{ padding:6px 10px; border-radius:6px; border:1px solid #222; background:transparent; cursor:pointer; }
.menu-toggle{ background:none; border:none; font-size:18px; cursor:pointer; }
</style>
