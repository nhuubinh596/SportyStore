<!-- src/components/admin/AdminLayout.vue -->
<template>
  <div class="admin-shell">
    <header class="app-header d-flex align-items-center justify-content-between p-2 border-bottom bg-white">
      <div class="ms-2"><strong>SportyClothes Admin</strong></div>
      <div class="d-flex align-items-center">
        <input class="form-control me-2" placeholder="Tìm sản phẩm..." style="width:420px"/>
        <div class="me-3">Xin chào, <strong class="ms-1">{{ currentUser?.username }}</strong></div>
        <button class="btn btn-outline-secondary btn-sm me-2" @click="onLogout">Đăng xuất</button>
      </div>
    </header>

    <div class="d-flex">
      <aside class="admin-sidebar bg-light p-3" style="width:200px; min-height: calc(100vh - 56px)">
        <div class="mb-3">
          <button class="btn btn-dark w-100 mb-2" :class="{'active': isActive('/admin')}" @click="go('/admin')">Dashboard</button>
          <button class="btn btn-outline-dark w-100 mb-2" @click="go('/admin/products')">Sản phẩm</button>
          <button class="btn btn-dark w-100 mb-2" @click="go('/admin/categories')">Danh mục</button>
          <button class="btn btn-outline-dark w-100 mb-2" @click="go('/admin/orders')">Đơn hàng</button>
          <button class="btn btn-outline-dark w-100 mb-2" @click="go('/admin/users')">Tài khoản</button>
        </div>
      </aside>

      <main class="flex-fill p-4">
        <router-view />
      </main>
    </div>

    <footer class="text-center py-2 border-top bg-white">© SportyClothes - Demo</footer>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter, useRoute } from 'vue-router';

const router = useRouter();
const route = useRoute();

const currentUser = ref(null);
try {
  const raw = localStorage.getItem('currentUser');
  currentUser.value = raw ? JSON.parse(raw) : null;
} catch (e) {
  currentUser.value = null;
}

function onLogout() {
  localStorage.removeItem('currentUser');
  localStorage.removeItem('authToken');
  router.replace('/login');
}

function go(path) {
  router.push(path);
}

function isActive(p) {
  return route.path === p;
}
</script>

<style scoped>
.admin-sidebar button { text-align:left; padding: 10px; }
.admin-sidebar .active { background: #111; color: #fff; }
</style>
