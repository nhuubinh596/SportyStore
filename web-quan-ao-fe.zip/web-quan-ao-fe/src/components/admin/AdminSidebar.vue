<template>
  <aside class="admin-sidebar">
    <div class="profile">
      <img :src="avatarUrl" alt="avatar" class="avatar" />
      <div class="meta">
        <div class="name">{{ displayName }}</div>
        <div class="username">@{{ user?.username || 'guest' }}</div>
        <div class="role" :class="isAdmin ? 'role-admin' : 'role-user'">{{ roleLabel }}</div>
      </div>
    </div>

    <nav class="menu">
      <ul>
        <li><router-link to="/admin">Dashboard</router-link></li>
        <li><router-link to="/admin/users">Danh sách tài khoản</router-link></li>
        <li><router-link to="/admin/orders">Đơn hàng</router-link></li>
        <li><router-link to="/admin/categories">Danh mục</router-link></li>
        <li><router-link to="/admin/add-product">Thêm sản phẩm</router-link></li>
      </ul>
    </nav>

    <div class="account-actions">
      <router-link class="btn-link" :to="profilePath">Trang cá nhân</router-link>
      <button class="btn-logout" @click="logout">Đăng xuất</button>
    </div>
  </aside>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const user = ref(null)

onMounted(() => {
  try {
    const json = localStorage.getItem('currentUser')
    user.value = json ? JSON.parse(json) : null
  } catch (e) {
    user.value = null
  }
})

const displayName = computed(() => user.value?.name || user.value?.username || 'Khách')
const roleLabel = computed(() => {
  if (!user.value) return 'GUEST'
  const r = user.value.role || (user.value.roles && user.value.roles[0]) || ''
  return String(r).replace(/^ROLE_/, '').toUpperCase() || 'USER'
})
const isAdmin = computed(() => String(roleLabel.value).toLowerCase().includes('admin') )

// avatar placeholder: nếu backend có avatar url thì dùng user.avatar
const avatarUrl = computed(() => user.value?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(displayName.value)}&background=fff&color=000`)

const profilePath = '/admin/profile' // admin profile route

function logout() {
  // xóa local storage và quay về login
  localStorage.removeItem('currentUser')
  localStorage.removeItem('authToken')
  // đôi khi muốn gọi API logout -> thêm axios nếu cần
  router.replace('/login')
}
</script>

<style scoped>
.admin-sidebar{
  width: 220px;
  background: #fff;
  padding: 18px;
  border-right: 1px solid #eee;
  min-height: 100vh;
  box-sizing: border-box;
}
.profile{ display:flex; gap:12px; align-items:center; margin-bottom:14px;}
.avatar{ width:54px; height:54px; border-radius:8px; object-fit:cover; border:1px solid #eee;}
.meta .name{ font-weight:700; }
.meta .username{ font-size:12px; color:#666; }
.role{ margin-top:6px; font-size:11px; display:inline-block; padding:3px 8px; border-radius:12px; font-weight:600; }
.role-admin{ background:#fdecea; color:#b02a37; border:1px solid #ffd3d3; }
.role-user{ background:#eefaf1; color:#1b6b2e; border:1px solid #d7f0da; }

.menu ul{ list-style:none; padding:0; margin: 10px 0 18px; }
.menu li{ margin:8px 0; }
.menu a{ color:#222; text-decoration:none; }
.menu a.router-link-exact-active{ font-weight:700; }

.account-actions{ display:flex; flex-direction:column; gap:8px; margin-top:auto; }
.btn-link{ color:#0b5ed7; text-decoration:underline; cursor:pointer; }
.btn-logout{ background:transparent; border:1px solid #222; padding:6px 10px; cursor:pointer; border-radius:6px; }
</style>
