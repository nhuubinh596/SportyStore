<!-- src/components/Auth/Register.vue -->
<template>
  <div class="d-flex align-items-center justify-content-center" style="min-height:100vh; background:#f6f7f9">
    <div style="width:560px">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title mb-3">Đăng ký</h5>

          <form @submit.prevent="onSubmit" novalidate>
            <label class="form-label small">Username</label>
            <input v-model="form.username" class="form-control mb-2" />

            <label class="form-label small">Họ và tên</label>
            <input v-model="form.name" class="form-control mb-2" />

            <label class="form-label small">Email</label>
            <input v-model="form.email" class="form-control mb-2" />

            <label class="form-label small">Mật khẩu</label>
            <input v-model="form.password" type="password" class="form-control mb-2" />

            <div class="mt-3">
              <button class="btn btn-dark" :disabled="loading">
                <span v-if="!loading">Đăng ký</span>
                <span v-else class="spinner-border spinner-border-sm"></span>
              </button>
              <small class="ms-3" v-if="statusText" :class="statusClass">{{ statusText }}</small>
            </div>
          </form>

        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue';
import { registerUser } from '../../api';
import { useRouter } from 'vue-router';

const router = useRouter();
const form = reactive({ username: '', name: '', email: '', password: '' });
const loading = ref(false);
const statusText = ref('');
const statusClass = ref('text-muted');

async function onSubmit() {
  statusText.value = '';
  if (!form.username || !form.email || !form.password) {
    statusText.value = 'Nhập đủ thông tin';
    statusClass.value = 'text-danger';
    return;
  }
  loading.value = true;
  try {
    const res = await registerUser(form);
    statusText.value = 'Đăng ký thành công. Vui lòng đăng nhập.';
    statusClass.value = 'text-success';
    setTimeout(() => router.replace('/login'), 900);
  } catch (e) {
    statusText.value = e?.response?.data?.message || 'Lỗi đăng ký';
    statusClass.value = 'text-danger';
  } finally {
    loading.value = false;
  }
}
</script>

<style scoped>
.card { border-radius: 10px; }
</style>
