<!-- src/components/Auth/Login.vue -->
<template>
  <div class="d-flex align-items-center justify-content-center" style="min-height:100vh; background:#f6f7f9">
    <div style="width:480px">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title mb-3">Đăng nhập</h5>

          <form @submit.prevent="onLogin">
            <div class="mb-2">
              <label class="form-label small">Username</label>
              <input v-model="username" class="form-control" placeholder="Username"/>
            </div>

            <div class="mb-3">
              <label class="form-label small">Password</label>
              <input v-model="password" type="password" class="form-control" placeholder="Password"/>
            </div>

            <div class="d-flex align-items-center justify-content-between">
              <button class="btn btn-dark" :disabled="loading">
                <span v-if="!loading">Login</span>
                <span v-else class="spinner-border spinner-border-sm"></span>
              </button>

              <div>
                <small v-if="statusText" :class="statusClass">{{ statusText }}</small>
              </div>
            </div>
          </form>

          <hr/>
          <div class="mt-2">
            <small>Chưa có tài khoản? <router-link to="/register">Đăng ký</router-link></small>
          </div>

        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { loginUser } from '../../api';

const router = useRouter();
const username = ref('');
const password = ref('');
const loading = ref(false);
const statusText = ref('');
const statusClass = ref('text-muted');

function normalizeAndSave(resData) {
  // resData can be many shapes: { user, token } or { data: {...} } or user object
  let user = null;
  let token = null;

  if (!resData) return false;

  // axios response wrapper check (if someone passed full res)
  if (resData.data && (resData.data.user || resData.data.token)) {
    user = resData.data.user || resData.data;
    token = resData.data.token || resData.data.authToken || resData.data.accessToken;
  } else if (resData.user || resData.token) {
    user = resData.user;
    token = resData.token;
  } else if (resData.username) {
    user = resData;
  } else if (resData.data) {
    user = resData.data;
  } else {
    return false;
  }

  // ensure role presence
  if (!user.role) {
    if (user.roles && user.roles.length) user.role = user.roles[0];
    else {
      const uname = (user.username || '').toLowerCase();
      user.role = uname.includes('admin') ? 'ROLE_ADMIN' : 'ROLE_USER';
    }
  }
  if (!user.roles) user.roles = [user.role];

  localStorage.setItem('currentUser', JSON.stringify(user));
  if (token) localStorage.setItem('authToken', token);
  return user;
}

async function onLogin() {
  statusText.value = '';
  statusClass.value = 'text-muted';

  if (!username.value || !password.value) {
    statusText.value = 'Nhập username và password';
    statusClass.value = 'text-danger';
    return;
  }

  loading.value = true;
  try {
    const res = await loginUser(username.value, password.value);
    // axios response: res.data
    const data = res.data ?? res;
    const saved = normalizeAndSave(data);
    if (!saved) {
      statusText.value = 'Server trả format lạ';
      statusClass.value = 'text-danger';
      return;
    }
    statusText.value = 'OK';
    statusClass.value = 'text-success';

    // redirect
    const role = (saved.role || '').toLowerCase();
    setTimeout(() => {
      if (role.includes('admin')) router.replace('/admin');
      else router.replace('/user');
    }, 250);
  } catch (err) {
    console.error('Login error', err);
    const msg = err?.response?.data?.message || err.message || 'Lỗi kết nối';
    statusText.value = msg;
    statusClass.value = 'text-danger';
  } finally {
    loading.value = false;
  }
}
</script>

<style scoped>
.card { border-radius: 10px; }
</style>
