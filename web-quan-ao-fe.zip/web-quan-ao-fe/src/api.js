// src/api.js
// API client for frontend. Uses axios and provides named exports for all operations.
// If backend is down, functions return sensible mock data so UI still works for demo.

import axios from 'axios'

/* ------------ Configuration ------------ */
export const BASE_URL = 'http://localhost:8080/api' // <-- change if backend different
const client = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
})

// attach token automatically if present
client.interceptors.request.use(cfg => {
  const token = localStorage.getItem('authToken')
  if (token) cfg.headers.Authorization = `Bearer ${token}`
  return cfg
}, e => Promise.reject(e))

/* ------------ Helpers ------------ */
async function safeRequest(promise, fallback = null) {
  try {
    const res = await promise
    return res.data ?? res
  } catch (err) {
    // Log for debug, then return fallback so UI can still render
    console.warn('[API] request failed, fallback used:', err?.message || err)
    return fallback
  }
}

function wrapSuccess(data) {
  return { success: true, data }
}

/* ------------ Mock Data for demo fallback ------------ */
const mockProducts = [
  { id: 1, title: 'Áo Thun DryFit Xanh', price: 299000, categoryId: 2, img: '/logo.svg', stock: 10 },
  { id: 2, title: 'Quần Short Nam Đen', price: 199000, categoryId: 3, img: '/logo.svg', stock: 25 },
  { id: 3, title: 'Giày Lightning', price: 1290000, categoryId: 4, img: '/logo.svg', stock: 5 },
  { id: 4, title: 'Mũ Lưỡi Trai', price: 150000, categoryId: 5, img: '/logo.svg', stock: 30 }
]
let mockProductsNextId = 5

const mockCategories = [
  { id: 1, name: 'Tất cả' },
  { id: 2, name: 'Áo' },
  { id: 3, name: 'Quần' },
  { id: 4, name: 'Giày' },
  { id: 5, name: 'Phụ kiện' }
]

const mockUsers = [
  { id: 1, username: 'user1', name: 'Admin One', role: 'ROLE_ADMIN', email: 'admin@example.com' },
  { id: 2, username: 'user2', name: 'Customer Two', role: 'ROLE_USER', email: 'user2@example.com' }
]
let mockUserNextId = 3

const mockOrders = []
let mockOrderNextId = 1

/* ------------ AUTH ------------ */

// login: expects backend returns { user, token } or similar
export async function loginUser({ username, password }) {
  const fallback = { success: true, user: mockUsers.find(u => u.username === username) ?? { username }, token: null }
  return safeRequest(client.post('/auth/login', { username, password }), fallback)
}

export async function registerUser(payload) {
  // payload: { username, name, email, password }
  const fallback = { success: true, user: { id: mockUserNextId++, ...payload, role: 'ROLE_USER' } }
  // If backend up => call it; otherwise add to mockUsers
  const res = await safeRequest(client.post('/auth/register', payload), null)
  if (!res) {
    mockUsers.push(fallback.user)
    return fallback
  }
  return res
}

/* ------------ PRODUCTS (CRUD) ------------ */

export async function getProducts({ params } = {}) {
  // params optional: { q, categoryId, maxPrice }
  const fallback = mockProducts.slice()
  const res = await safeRequest(client.get('/products', { params }), fallback)
  // normalize common shapes
  if (Array.isArray(res)) return res
  if (res?.data && Array.isArray(res.data)) return res.data
  if (res?.products && Array.isArray(res.products)) return res.products
  return res ?? fallback
}

export async function getProduct(id) {
  const res = await safeRequest(client.get(`/products/${id}`), mockProducts.find(p => p.id === +id) ?? null)
  return res
}

export async function createProduct(payload) {
  // payload: { title, price, categoryId, img, stock }
  const fallback = { success: true, product: { id: mockProductsNextId++, ...payload } }
  const res = await safeRequest(client.post('/products', payload), fallback)
  if (!res || !res.product) {
    // add to mock list
    mockProducts.push(fallback.product)
    return fallback
  }
  return res
}

export async function updateProduct(id, payload) {
  const fallback = { success: true, product: { id: +id, ...payload } }
  const res = await safeRequest(client.put(`/products/${id}`, payload), fallback)
  if (!res || !res.product) {
    const idx = mockProducts.findIndex(p => p.id === +id)
    if (idx >= 0) mockProducts[idx] = { ...mockProducts[idx], ...payload }
    return fallback
  }
  return res
}

export async function deleteProduct(id) {
  const fallback = { success: true, id }
  const res = await safeRequest(client.delete(`/products/${id}`), fallback)
  if (!res || !res.success) {
    const idx = mockProducts.findIndex(p => p.id === +id)
    if (idx >= 0) mockProducts.splice(idx, 1)
    return fallback
  }
  return res
}

/* ------------ CATEGORIES (CRUD) ------------ */
export async function getCategories() {
  const fallback = mockCategories.slice()
  const res = await safeRequest(client.get('/categories'), fallback)
  if (Array.isArray(res)) return res
  if (res?.data && Array.isArray(res.data)) return res.data
  return res ?? fallback
}

export async function createCategory(payload) {
  const fallback = { success: true, category: { id: mockCategories.length + 1, ...payload } }
  const res = await safeRequest(client.post('/categories', payload), fallback)
  if (!res || !res.category) {
    mockCategories.push(fallback.category)
    return fallback
  }
  return res
}

export async function updateCategory(id, payload) {
  const fallback = { success: true, category: { id: +id, ...payload } }
  const res = await safeRequest(client.put(`/categories/${id}`, payload), fallback)
  if (!res || !res.category) {
    const idx = mockCategories.findIndex(c => c.id === +id)
    if (idx >= 0) mockCategories[idx] = { ...mockCategories[idx], ...payload }
    return fallback
  }
  return res
}

export async function deleteCategory(id) {
  const fallback = { success: true, id }
  const res = await safeRequest(client.delete(`/categories/${id}`), fallback)
  if (!res || !res.success) {
    const idx = mockCategories.findIndex(c => c.id === +id)
    if (idx >= 0) mockCategories.splice(idx, 1)
    return fallback
  }
  return res
}

/* ------------ ORDERS ------------ */
export async function getOrders(params = {}) {
  const fallback = mockOrders.slice()
  const res = await safeRequest(client.get('/orders', { params }), fallback)
  if (Array.isArray(res)) return res
  if (res?.data && Array.isArray(res.data)) return res.data
  return res ?? fallback
}

export async function getOrder(id) {
  const res = await safeRequest(client.get(`/orders/${id}`), mockOrders.find(o => o.id === +id) ?? null)
  return res
}

export async function createOrder(payload) {
  // payload: { userId, items: [{productId, qty}], total }
  const fallback = { success: true, order: { id: mockOrderNextId++, status: 'NEW', createdAt: new Date().toISOString(), ...payload } }
  const res = await safeRequest(client.post('/orders', payload), fallback)
  if (!res || !res.order) {
    mockOrders.push(fallback.order)
    return fallback
  }
  return res
}

export async function updateOrder(id, payload) {
  const fallback = { success: true, order: { id: +id, ...payload } }
  const res = await safeRequest(client.put(`/orders/${id}`, payload), fallback)
  if (!res || !res.order) {
    const idx = mockOrders.findIndex(o => o.id === +id)
    if (idx >= 0) mockOrders[idx] = { ...mockOrders[idx], ...payload }
    return fallback
  }
  return res
}

/* ------------ USERS (admin) ------------ */
export async function getUsers(params = {}) {
  const fallback = mockUsers.slice()
  const res = await safeRequest(client.get('/users', { params }), fallback)
  if (Array.isArray(res)) return res
  if (res?.data && Array.isArray(res.data)) return res.data
  return res ?? fallback
}

export async function getUser(id) {
  const res = await safeRequest(client.get(`/users/${id}`), mockUsers.find(u => u.id === +id) ?? null)
  return res
}

export async function updateUser(id, payload) {
  const fallback = { success: true, user: { id: +id, ...payload } }
  const res = await safeRequest(client.put(`/users/${id}`, payload), fallback)
  if (!res || !res.user) {
    const idx = mockUsers.findIndex(u => u.id === +id)
    if (idx >= 0) mockUsers[idx] = { ...mockUsers[idx], ...payload }
    return fallback
  }
  return res
}

export async function deleteUser(id) {
  const fallback = { success: true, id }
  const res = await safeRequest(client.delete(`/users/${id}`), fallback)
  if (!res || !res.success) {
    const idx = mockUsers.findIndex(u => u.id === +id)
    if (idx >= 0) mockUsers.splice(idx, 1)
    return fallback
  }
  return res
}
// interceptor: attach auth token if present
client.interceptors.request.use(cfg => {
  const token = localStorage.getItem('authToken');
  if (token) cfg.headers = { ...cfg.headers, Authorization: `Bearer ${token}` };
  return cfg;
}, e => Promise.reject(e));

export async function loginUser(username, password) {
  return client.post('/auth/login', { username, password });
}

export async function registerUser(payload) {
  return client.post('/auth/register', payload);
}

export async function fetchProducts() {
  return client.get('/products');
}

export async function fetchCategories() {
  return client.get('/categories');
}

export default client;
